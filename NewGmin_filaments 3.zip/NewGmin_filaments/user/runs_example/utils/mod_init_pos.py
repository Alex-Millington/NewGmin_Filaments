#This module makes the initial position of the rods

import numpy as np
from pylab import pi
import sys,os

#---------------------------------------------------------------------------------------------------------------------------------
#Write initpos
#---------------------------------------------------------------------------------------------------------------------------------
def write_initpos(initpos):
	if not os.path.exists('data'):
		os.mkdir('data')
		
	with open('data'+'/init_pos','w') as f:
		for i in range(0,len(initpos)):
			f.write(("%s "*2 + "\n") %(initpos[i][0],initpos[i][1]))
	return
#---------------------------------------------------------------------------------------------------------------------------------


#---------------------------------------------------------------------------------------------------------------------------------
#Make the initial positions of the rods
#---------------------------------------------------------------------------------------------------------------------------------
def init_pos(shape_name,L,M,spacing,radius):

	if shape_name=='HEX_CIRCLE':
		#Make a hexagonal array of rods up to a circular cutoff radius. The following definitions are used:
		#L - DUMMY
		#M - DUMMY
		#spacing - distance between neighbouring rods
		#radius - radius of circular confinement
		
		initpos=[]
		n_steps=int(np.ceil(radius/spacing))+4
		
		for i in range(-n_steps,n_steps+1):
			for j in range(-n_steps,n_steps+1):
				x=(0.5*np.mod(j,2)+i)*spacing
				y=j*np.sqrt(3.0)/2.0
				
				if np.sqrt(x**2+y**2)<=radius:
					initpos.append([x,y])
		
		
	write_initpos(initpos)			
	print(shape_name,L,M,spacing,radius)
	
	return initpos
#---------------------------------------------------------------------------------------------------------------------------------

if __name__ == "__main__":
    import sys
    import numpy as np
