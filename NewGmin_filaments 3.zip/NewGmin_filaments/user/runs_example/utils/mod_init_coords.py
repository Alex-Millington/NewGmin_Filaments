#This module makes the initial angular position of the rods

import numpy as np
from pylab import pi
import sys,os


#---------------------------------------------------------------------------------------------------------------------------------
#Write coords
#---------------------------------------------------------------------------------------------------------------------------------
def write_coords(coords):
	if not os.path.exists('data'):
		os.mkdir('data')
		
	np.savetxt("data/coords",coords,fmt="%14.10f")
	
	return
#---------------------------------------------------------------------------------------------------------------------------------

#---------------------------------------------------------------------------------------------------------------------------------
#Define the initial system
#---------------------------------------------------------------------------------------------------------------------------------
def make_coords(initpos, N_SEG, first=False):
	N_RODS=len(initpos)
	
	if first:
		coords=np.random.rand(2*N_RODS*(N_SEG))*0.001
	else: # read the previous minima as the new initial configuration
		with open("lowest", "r") as file:
			lines = file.readlines()
			coords = np.array([float(line.strip()) for line in lines[4:] if line.strip()], dtype=np.float64)
			coords += np.random.rand(2*N_RODS*(N_SEG))*0.001
	
	write_coords(coords)
	return

#---------------------------------------------------------------------------------------------------------------------------------
	
	
if __name__ == "__main__":
    import sys
    import numpy as np
    
