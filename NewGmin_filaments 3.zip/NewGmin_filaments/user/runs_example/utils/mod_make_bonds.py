#This module makes the bonds between the rods

import numpy as np
from pylab import pi
import sys,os


#---------------------------------------------------------------------------------------------------------------------------------
#Write bonds
#---------------------------------------------------------------------------------------------------------------------------------
def write_bonds(bonds):
	if not os.path.exists('data'):
		os.mkdir('data')
		
	with open('data'+'/bonds','w') as f:
		for i in range(0,len(bonds)):
			f.write(("%s "*4 + "\n") %(bonds[i][0],bonds[i][1],bonds[i][2],bonds[i][3]))
	return
#---------------------------------------------------------------------------------------------------------------------------------


#---------------------------------------------------------------------------------------------------------------------------------
#Makes the bonds between the rods
#---------------------------------------------------------------------------------------------------------------------------------
def make_bonds(neighbs,N_SEG):

	n_rods=np.shape(neighbs)[0]
	n_cols=np.shape(neighbs)[1]
	
	bonds=[]
	bond_count=0
	
	for i in range(0,n_rods):
		for j in range(0,n_cols):
			if neighbs[i,j]==-1:
				break
			else:
				for k in range(1,N_SEG+1):
	
					#0 bond
					inlist=False
					for c in range(0,bond_count):
						if bonds[c]==[i,k,neighbs[i,j],k] or bonds[c]==[neighbs[i,j],k,i,k]:
							inlist=True
							break
							
					if inlist==False:
						bonds.append([i,k,neighbs[i,j],k])
						
					#+1 bond
					if k<N_SEG:
						inlist=False
						for c in range(0,bond_count):
							if bonds[c]==[i,k,neighbs[i,j],k+1] or bonds[c]==[neighbs[i,j],k+1,i,k]:
								inlist=True
								break
								
						if inlist==False:
							bonds.append([i,k,neighbs[i,j],k+1])	
							
					#-1 bond		
					inlist=False
					for c in range(0,bond_count):
						if bonds[c]==[i,k,neighbs[i,j],k-1] or bonds[c]==[neighbs[i,j],k-1,i,k]:
							inlist=True
							break
							
					if inlist==False:
						bonds.append([i,k,neighbs[i,j],k-1])													
						
	write_bonds(bonds)
	return bonds
#---------------------------------------------------------------------------------------------------------------------------------
	
		
	
#---------------------------------------------------------------------------------------------------------------------------------
#Write bond properties
#---------------------------------------------------------------------------------------------------------------------------------
def write_bond_properties(bond_properties):
	if not os.path.exists('data'):
		os.mkdir('data')
		
	with open('data'+'/bond_properties','w') as f:
		for i in range(0,len(bond_properties)):
			f.write(("%s "*2 + "\n") %(bond_properties[i,0],bond_properties[i,1]))
	return
#---------------------------------------------------------------------------------------------------------------------------------
	
	
	
	
#---------------------------------------------------------------------------------------------------------------------------------
#Find the equilirbium bond lengths and store stretching stiffnesses
#---------------------------------------------------------------------------------------------------------------------------------
def equilb_bonds(initpos,bonds,LENGTH,N_SEG,k_bond):

	N_BONDS=len(bonds)
	
	bond_properties=np.zeros([N_BONDS,2])
	
	LS=LENGTH/N_SEG

	#Store the bond stretching energies
	for i in range(0,N_BONDS):
		bond_properties[i,1]=k_bond

	#Compute and store the equilibrium bond lengths
	for i in range(0,N_BONDS):
		#Extract the rods and segments forming the bond 
		r1=bonds[i][0]
		s1=bonds[i][1]
		r2=bonds[i][2]
		s2=bonds[i][3]
		
		#Convert the rod and segment positions to coordinates
		x1=initpos[r1][0]
		y1=initpos[r1][1]
		z1=s1*LS
		
		x2=initpos[r2][0]
		y2=initpos[r2][1]
		z2=s2*LS	
		
		#Compute the bond length - this will be the equilibrium distance in the unperturbed system
		equilb_length=np.sqrt((x2-x1)**2+(y2-y1)**2+(z2-z1)**2)
		
		#Store the equilibrium length
		bond_properties[i,0]=equilb_length
			
																
	write_bond_properties(bond_properties)
	return
#---------------------------------------------------------------------------------------------------------------------------------
		
	
	
if __name__ == "__main__":
    import sys
    import numpy as np	



