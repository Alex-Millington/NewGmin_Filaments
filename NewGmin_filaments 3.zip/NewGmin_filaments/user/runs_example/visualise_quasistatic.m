%% Script to animate the initial position of the 3D laminar buckling system with thick rods

PATHTORUNDIR = '/.../NewGmin_filaments/user/runs_example'; % your path
INITPOSNAME = 'data/init_pos';
ANGLESFOLDER = 'quasistatic_coords';
ANGLES_PREFIX = 'lowest_';
NHEADER = 4;
LENGTH = 20;

savestat = 1;
animation_filename = [PATHTORUNDIR '/buckling_animation.gif'];

n_circ = 12; % Number of points to define the rod cross-section
r_circ = 0.1; % Radius of the rod cross-section
view([0.5 -0.6 0.3])
%% Read in initial positions
initpos_in = importdata([PATHTORUNDIR '/' INITPOSNAME]);
N_RODS = length(initpos_in);

% Get all angle files
angle_files = dir([PATHTORUNDIR '/' ANGLESFOLDER '/' ANGLES_PREFIX '*']);

% Extract numbers from the filenames and sort numerically
file_names = {angle_files.name};
file_numbers = regexp(file_names, '\d+', 'match'); % Extract numbers as strings
file_numbers = cellfun(@(x) str2double(x{end}), file_numbers); % Convert to numeric
[~, sorted_idx] = sort(file_numbers); % Sort the numbers
angle_files = angle_files(sorted_idx); % Reorder the structure array


num_frames = length(angle_files);

% Set up figure
fig = figure;
axis equal;
axis tight;
hold on;
light('Position', [1 0.7 0.7]);
material shiny;
lighting phong;

for frame_idx = 1:num_frames
    cla;
    hold on;
    angle_file = [PATHTORUNDIR '/' ANGLESFOLDER '/' angle_files(frame_idx).name];
    angles = importdata(angle_file, '', NHEADER);
    if NHEADER > 0
        angles = angles.data;
    end
    
    N_SEG = length(angles) / (2 * N_RODS);
    LS = LENGTH / N_SEG;
    NUM_ANGLES = N_RODS * N_SEG;
    coords = zeros([N_RODS, N_SEG+1, 3]);
    
    %% Compute coordinates
    for irod = 1:N_RODS
        coords(irod,1,2) = initpos_in(irod,1);
        coords(irod,1,3) = initpos_in(irod,2);    
        coords(irod,1,1) = 0;
        
        for iseg = 2:N_SEG+1
            cur = (irod-1)*N_SEG+iseg-1;
            theta = angles(cur);
            phi = angles(NUM_ANGLES+cur);
            
            coords(irod,iseg,1) = coords(irod,iseg-1,1) + LS * cos(theta) * cos(phi);
            coords(irod,iseg,2) = coords(irod,iseg-1,2) + LS * sin(theta) * cos(phi);
            coords(irod,iseg,3) = coords(irod,iseg-1,3) + LS * sin(phi);
        end
    end
    
    %% Plot rods
    for irod = 1:N_RODS
        verts = zeros(n_circ * (N_SEG + 1), 3);
        faces = zeros(n_circ * N_SEG, 4);

        for iseg = 1:N_SEG+1
            if iseg == N_SEG+1
                l = squeeze(coords(irod, iseg, :) - coords(irod, iseg-1, :));
            else
                l = squeeze(coords(irod, iseg+1, :) - coords(irod, iseg, :));
            end
            lnorm = l / norm(l);
            n = [1; -lnorm(1)/lnorm(2); 0]; % Generate a perpendicular vector
            n = n / norm(n) * r_circ; % Scale to radius

            if n(2) < 0
                n = -n;
            end

            for icirc = 1:n_circ
                theta = 2 * pi * icirc / n_circ;
                % Compute rotated normal vector
                n_rot = n' * cos(theta) + cross(lnorm, n)' * sin(theta) + lnorm' * (dot(lnorm, n) * (1 - cos(theta)));
                % Update vertices
                verts((iseg-1)*n_circ + icirc, :) = squeeze(coords(irod, iseg, :))' + n_rot;
            end
        end

        for iseg = 1:N_SEG
            for icirc = 1:n_circ-1
                faces((iseg-1)*n_circ + icirc, :) = [
                    (iseg-1)*n_circ + icirc,
                    iseg*n_circ + icirc,
                    iseg*n_circ + icirc+1,
                    (iseg-1)*n_circ + icirc+1
                ];
            end
            faces((iseg-1)*n_circ + n_circ, :) = [
                (iseg-1)*n_circ + n_circ,
                iseg*n_circ + n_circ,
                iseg*n_circ + 1,
                (iseg-1)*n_circ + 1
            ];
        end

        % Plot as patch
        patch('Faces', faces, 'Vertices', verts, 'FaceColor', 'y', 'EdgeColor', 'none');
    end
    axis equal
    axis tight

    xlim([-2, LENGTH + 2]);
    ylim([-3, 3]);
    zlim([-3, 3]);

    light('Position',[1 0.7 0.7])
    material shiny
    lighting phong
    view([0.5 -0.6 0.3])
    %title(['Net Winding ' sprintf('%.2f', frame_idx / 100) '  Twist Constant 1.0  Axial Load 0.0']);
    %title(['Run ' sprintf('%.0f', frame_idx)])
    %% Capture frame for animation
    frame = getframe(fig);
    img = imresize(frame2im(frame), 0.5); % Scale down resolution for speed
    [imind, cm] = rgb2ind(img, 256);

    % Write to GIF
    if frame_idx == 1
        imwrite(imind, cm, animation_filename, 'gif', 'Loopcount', inf, 'DelayTime', 0);
    else
        imwrite(imind, cm, animation_filename, 'gif', 'WriteMode', 'append', 'DelayTime', 0);
    end
end

disp(['Animation saved as: ' animation_filename]);