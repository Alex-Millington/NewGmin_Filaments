#This module computes the neighbours of each rod

import numpy as np
from pylab import pi
import sys,os

#---------------------------------------------------------------------------------------------------------------------------------
#Write neighbs
#---------------------------------------------------------------------------------------------------------------------------------
def write_neighbs(neighbs):
	if not os.path.exists('data'):
		os.mkdir('data')
		
	np.savetxt("data/neighbs",neighbs,fmt='%s')
	return
#---------------------------------------------------------------------------------------------------------------------------------

	
#---------------------------------------------------------------------------------------------------------------------------------
#Finds the nearest neighbours to each rod	
#---------------------------------------------------------------------------------------------------------------------------------
def find_neighbours(initpos,bond_tolerance,rod_spacing):
	#Definitions:
	#initpos - the array of positions of the rod ends
	#bond_tolerance - if a rod is in the set of nearest neighbours of another, it is within bond_tolerance of the fractional minimum nearest neighbour distance
	
	#find_neighbours.1) Find the nearest neighbours
	n_rods=len(initpos)
	
	#find_neighbours.1.1) Find the nearest neighbour
	min_bl_array=np.zeros([n_rods],dtype=float)+1E10
	for i in range(0,n_rods):
		x1=initpos[i][0]
		y1=initpos[i][1]
		for j in range(i+1,n_rods):
			x2=initpos[j][0]
			y2=initpos[j][1]
			
			dist=np.sqrt((x2-x1)**2+(y2-y1)**2)
			
			if dist<min_bl_array[i]:
				min_bl_array[i]=dist
				
			if dist<min_bl_array[j]:
				min_bl_array[j]=dist
	
	
				
	#find_neighbours.1.2) Now find the set of nearest neighbours within a tolerance
	neighbs=np.zeros([n_rods,12],dtype='int')-1 # We assume no rod will have more than 12 neighbours
	neighb_count=np.zeros([n_rods],dtype='int')	
	
	for i in range(0,n_rods):
		x1=initpos[i][0]
		y1=initpos[i][1]
		for j in range(i+1,n_rods):
			x2=initpos[j][0]
			y2=initpos[j][1]
			
			dist=np.sqrt((x2-x1)**2+(y2-y1)**2)
			
			if dist<=min_bl_array[i]*(1+bond_tolerance):
				neighbs[i,neighb_count[i]]=j
				neighb_count[i]+=1
				
			if dist<=min_bl_array[j]*(1+bond_tolerance):
				neighbs[j,neighb_count[j]]=i
				neighb_count[j]+=1
			
	
	write_neighbs(neighbs)	
	return neighbs	
#---------------------------------------------------------------------------------------------------------------------------------

if __name__ == "__main__":
    import sys
    import numpy as np
