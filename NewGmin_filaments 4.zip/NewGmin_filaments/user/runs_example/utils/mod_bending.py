#This module makes the bending energies of the rods
import numpy as np
from pylab import pi
import sys,os


#---------------------------------------------------------------------------------------------------------------------------------
#Write tetrahedra
#---------------------------------------------------------------------------------------------------------------------------------
def write_bending_energy(b_eng):
	if not os.path.exists('data'):
		os.mkdir('data')
		
	with open('data'+'/bending_energy','w') as f:
		for i in range(0,len(b_eng)):
			f.write(("%s " + "\n") %(b_eng[i]))
	return
#---------------------------------------------------------------------------------------------------------------------------------





#---------------------------------------------------------------------------------------------------------------------------------
#Defines the bending energy (can be made variable)
#---------------------------------------------------------------------------------------------------------------------------------
def make_bending_energy(initpos,neighbs,N_SEG,BE,BE_FAC):

	N_RODS=len(initpos)
	b_eng=np.zeros([N_RODS*N_SEG])+BE

	#for irod in range(0,N_RODS):
	#	rad=np.sqrt(initpos[irod][0]**2+initpos[irod][1]**2)
	#	if rad>=RAD_OUTER:
	#		b_eng[irod*N_SEG:(irod+1)*N_SEG]=BE*BE_FAC
	for irod in range(0,N_RODS):
		#Count the number of neighbours-if its less than 6, its an outer rod
		neighbs_irod=neighbs[irod,:]
		neighblist=neighbs_irod.tolist()
		n_neighbs=np.shape(neighbs)[1] - neighblist.count(-1)
		
		if n_neighbs<6:
			b_eng[irod*N_SEG:(irod+1)*N_SEG]=BE*BE_FAC

	write_bending_energy(b_eng)
	return
#---------------------------------------------------------------------------------------------------------------------------------




