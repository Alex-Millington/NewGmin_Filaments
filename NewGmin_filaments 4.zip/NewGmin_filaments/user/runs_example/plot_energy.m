%% Script to animate the initial position of the 3D laminar buckling system with thick rods

PATHTORUNDIR = '/.../NewGmin_filaments/user/runs_example'; % your path
INITPOSNAME = 'data/init_pos';
ANGLESFOLDER = 'quasistatic_coords';
ANGLES_PREFIX = 'lowest_';
NHEADER = 4;
LENGTH = 20;

savestat = 1;
animation_filename = [PATHTORUNDIR '/buckling_animation.gif'];
energy_plot_filename = [PATHTORUNDIR '/energy_vs_winding.png'];

n_circ = 12; % Number of points to define the rod cross-section
r_circ = 0.1; % Radius of the rod cross-section
view([0.5 -0.6 0.3])

%% Read in initial positions
initpos_in = importdata([PATHTORUNDIR '/' INITPOSNAME]);
N_RODS = length(initpos_in);

%% Get all angle files
angle_files = dir([PATHTORUNDIR '/' ANGLESFOLDER '/' ANGLES_PREFIX '*']);

% Extract numbers from filenames and sort numerically
file_names = {angle_files.name};
file_numbers = regexp(file_names, '\d+', 'match'); % Extract numbers as strings
file_numbers = cellfun(@(x) str2double(x{end}), file_numbers); % Convert to numeric
[~, sorted_idx] = sort(file_numbers); % Sort the numbers
angle_files = angle_files(sorted_idx); % Reorder the structure array

num_frames = length(angle_files);

%% Initialize energy storage
net_winding = zeros(num_frames, 1);
energy_values = zeros(num_frames, 1);

%% Set up figure for energy plot
fig_energy = figure;
hold on;
xlabel('p');
ylabel('Energy');
%title('Energy vs Run Num');
grid on;

for frame_idx = 1:num_frames
    angle_file = [PATHTORUNDIR '/' ANGLESFOLDER '/' angle_files(frame_idx).name];
    
    %% Extract energy value from file
    fid = fopen(angle_file, 'r');
    energy_value = NaN;
    while ~feof(fid)
        line = fgetl(fid);
        if contains(line, 'Energy is')
            energy_value = sscanf(line, 'Energy is %f');
            break;
        end
    end
    fclose(fid);
    
    energy_values(frame_idx) = energy_value;
    net_winding(frame_idx) = frame_idx+2;
    
    %% Update energy plot
    figure(fig_energy);
    plot(net_winding(1:frame_idx), energy_values(1:frame_idx), 'r-', 'LineWidth', 2);
    drawnow;
end

%% Save final energy plot
saveas(fig_energy, energy_plot_filename);

disp(['Energy plot saved as: ' energy_plot_filename]);
