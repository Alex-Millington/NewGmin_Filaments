#This script will make the run folders and run gmin on the 3d laminar buckling models

import numpy as np
import sys,os
import subprocess
import time
from pylab import pi

from utils import mod_init_pos
from utils import mod_init_coords
from utils import mod_find_neighbours
from utils import mod_make_bonds
from utils import mod_make_tetrahedra
from utils import mod_bending

import os
os.chdir("/.../NewGmin_filaments/user/runs_example/") # replace with your path


#------------------------------------------------------------------------------------------------------------
# User inputs 
#------------------------------------------------------------------------------------------------------------
LENGTH=20 #Filament length (along x-axis)
N_RODS=37 #Number of rods
N_SEG=100 #Number of segments each rod is discretised into

Nx=0.00 #x-load (axial load)
Ny=0.00 #y-load
Nz=0.00 #z-load
Nrot=0.00 #Rotational load

k_bond=0.0001 #Bond stretching stiffness
BE=0.2 #Rod bending stiffness
BE_FAC=0.2 #Outer rod bending stiffness

CONF_R=3.1 # Radius of confining potential - THIS NEEDS TO BE LARGER THAN THE OUTERMOST ROD RADIUS!
CONF_STRENGTH=1.0 # Strength of confining potential
CONF_WIDTH=0.01 # Width of confining potential

OVERLAP_STRENGTH=1000 #Magnitude of the overlap potential (penalising tetrahedra of nodes tending to zero volume)
OVERLAP_EXP=100 #Exponent multiplier of the overlap potential

CLAMPED_ZERO=True # Applies angular constraint to base of bundle
CLAMPED_END=True # Applies angular constraint to end of bundle
CLAMP_STRENGTH=1000

TWIST_CONSTANT = 1.0

#Initial-position-specific inputs
#Inputs for 'HEX_CIRCLE' - a hexagonal array of rods within a circular footprint
rod_spacing=1.0 # Distance between neighbouring rods
circle_radius=3.0 # Radius of filament bundle

neighb_tolerance=0.01 #In the auto-bond function, all nearest neighbours are found (to within (bond_tolerance*100)% of rod_spacing)

#Input for 'RECTANGLE' - a rectangular array of rods - (JRP - not yet tested)

L_RODS=10
M_RODS=6
WIDTH=0.25
HEIGHT=0.25

if not os.path.exists("quasistatic_coords"):
    os.makedirs("quasistatic_coords")

total_start_time = time.time()

H = np.full(37, TWIST_CONSTANT)

with open("rod_energies", "w") as file:
        for i in range(1, N_RODS + 1):
            file.write(f"{i:4d} {0.0:15.6f}\n")

for k in range(0, 100):
	loop_start_time = time.time()
	
	# sliding window
	#p_windings = np.array([[k,k+20],[0,99]])
	#Lk = np.array([0.2, 0.0])

	# outgrowth model
	#p_windings = np.array([[0,p],[p,99]])
	#Lk = np.array([p, p-100])*0.005

	p_windings = np.array([0,99])
	Lk = np.array([0.01 * k])
	T = np.eye(N_SEG)*TWIST_CONSTANT
	N_constraints = len(p_windings)
	M = np.zeros((N_constraints, N_SEG))
	for i, (start, end) in enumerate(p_windings):
		M[i, start:end + 1] = 1  # end is inclusive
	H = np.linalg.inv((M @ np.linalg.inv(T)) @ M.T)
	#print("run",k," H ",H)

	with open("N_constraints.txt", "w") as f:
		f.write(f"{N_constraints}\n")
	np.savetxt("Lk_constraints.txt", Lk)
	np.savetxt("M_matrix.txt", M)
	np.savetxt("H_matrix.txt", H)

	#------------------------------------------------------------------------------------------------------------
	#functions
	#------------------------------------------------------------------------------------------------------------
	def write_datain():
		with open('data.in','w') as f:
			f.write(("%s" + "\n") %(N_RODS))
			f.write(("%s" + "\n") %(N_SEG))
			f.write(("%s" + "\n") %(N_BONDS))
			f.write(("%s" + "\n") %(N_TETRAHEDRA))
			f.write(("%s" + "\n") %(Nx))
			f.write(("%s" + "\n") %(Ny))
			f.write(("%s" + "\n") %(Nz))
			f.write(("%s" + "\n") %(Nrot))
			f.write(("%s" + "\n") %(LENGTH))
			f.write(("%s" + "\n") %(CONF_R))
			f.write(("%s" + "\n") %(CONF_STRENGTH))
			f.write(("%s" + "\n") %(CONF_WIDTH))
			f.write(("%s" + "\n") %(OVERLAP_STRENGTH))
			f.write(("%s" + "\n") %(OVERLAP_EXP))
			f.write(("%s" + "\n") %(CLAMPED_ZERO))
			f.write(("%s" + "\n") %(CLAMPED_END))
			f.write(("%s" + "\n") %(CLAMP_STRENGTH))
		return
	#------------------------------------------------------------------------------------------------------------
	#----------------------------------------------------------------------------------------------------------------------------------
	# Compile minimisation code
	#----------------------------------------------------------------------------------------------------------------------------------
	subprocess.run(["/.../NewGmin_filaments/GMIN","-n"]) # replace with your GMIN path
	#----------------------------------------------------------------------------------------------------------------------------------
		
	#------------------------------------------------------------------------------------------------------------
	#Main
	#------------------------------------------------------------------------------------------------------------
	#1)Initialise the base positions
	initpos=mod_init_pos.init_pos('HEX_CIRCLE',L_RODS,M_RODS,rod_spacing,circle_radius)
	N_RODS=len(initpos)

	#2) Find the neighbours of each rod
	neighbs=mod_find_neighbours.find_neighbours(initpos,neighb_tolerance,rod_spacing)

	#3) Make the elastic bonds between neighbouring vertices
	bonds=mod_make_bonds.make_bonds(neighbs,N_SEG)
	N_BONDS=len(bonds)
	mod_make_bonds.equilb_bonds(initpos,bonds,LENGTH,N_SEG,k_bond)

	#4) Initialise the array of angles
	if k == 0: #first time round, just randomise the angles
		mod_init_coords.make_coords(initpos,N_SEG,first = True)
	else: # then use the previous minima
		mod_init_coords.make_coords(initpos,N_SEG,first = False)
	
	#5) Make the tetrahedra
	tetrahedra=mod_make_tetrahedra.make_tetrahedra(neighbs,N_SEG,N_RODS)
	N_TETRAHEDRA=len(tetrahedra)
	mod_make_tetrahedra.equilb_tetrahedra(tetrahedra,initpos,LENGTH,N_RODS,N_SEG,N_TETRAHEDRA)

	#6) Make the bending stiffness array
	mod_bending.make_bending_energy(initpos,neighbs,N_SEG,BE,BE_FAC)

	print('System made with: N_RODS=',N_RODS, ', N_SEG=',N_SEG, ', N_BONDS=',N_BONDS, ', N_TETRAHEDRA=',N_TETRAHEDRA)
	write_datain()
	subprocess.run(["cp","data/coords","./coords"])

	#7) Run the minimisation
	subprocess.run(["/.../NewGmin_filaments/user/runs_example/gmin"]) # replace with your gmin path

	#8) Save each minima
	os.makedirs("quasistatic_coords", exist_ok=True)
	with open("lowest", "r") as src, open(f"quasistatic_coords/lowest_{k}", "w") as dest:
		dest.write(src.read())

	loop_end_time = time.time()  # End time for this iteration
	loop_duration = loop_end_time - loop_start_time
	print(f"Runtime for run {k + 1}: {loop_duration:.2f} seconds")

	#------------------------------------------------------------------------------------------------------------

total_end_time = time.time()
total_duration = total_end_time - total_start_time
print(f"Total runtime: {total_duration:.2f} seconds")

