#This module makes the initial position of the rods

import numpy as np
from pylab import pi
import sys,os


#---------------------------------------------------------------------------------------------------------------------------------
#Write tetrahedra
#---------------------------------------------------------------------------------------------------------------------------------
def write_tetrahedra(tetrahedra):
	if not os.path.exists('data'):
		os.mkdir('data')
		
	with open('data'+'/tetrahedra','w') as f:
		for i in range(0,len(tetrahedra)):
			array=tetrahedra[i]
			list_arr=' '.join(str(x) for x in array)
			f.write(("%s " + "\n") %(list_arr))
	return
#---------------------------------------------------------------------------------------------------------------------------------





#---------------------------------------------------------------------------------------------------------------------------------
#Identifies the tetrahedra
#---------------------------------------------------------------------------------------------------------------------------------
def make_tetrahedra(neighbs,N_SEG,N_RODS):

	tetrahedra=[]
	for irod in range(0,N_RODS):
	
		#1) Choose a rod
		ROD_A=irod
		#Get ROD_A's neighbour list (with all the -1's cut out):
		NEIGHBS_A=neighbs[ROD_A,:]
		NEIGHBS_A=NEIGHBS_A[NEIGHBS_A!=-1]
		
		#Loop through each of ROD_A's neighbours
		for ineighb in range(0,len(NEIGHBS_A)):
			ROD_B=NEIGHBS_A[ineighb]
			#Get ROD_B's neighbour list (with all the -1's cut out):
			NEIGHBS_B=neighbs[ROD_B,:]
			NEIGHBS_B=NEIGHBS_B[NEIGHBS_B!=-1]
			
			#Make a list of how many neighbours rod A and B have in common
			RODS_AB=np.intersect1d(NEIGHBS_A,NEIGHBS_B)
		
			#Loop through each of these common neighbours to form the triangular base of the tetrahedra
			for icom in range(0,len(RODS_AB)):
				ROD_C=RODS_AB[icom]
				
				for iseg in range(1,N_SEG+1):
					#Add the list of 4 coordinates making up the tetrahedron
					tetrahedra.append([ROD_A,iseg,ROD_A,iseg-1,ROD_B,iseg-1,ROD_C,iseg-1])
					tetrahedra.append([ROD_A,iseg,ROD_A,iseg-1,ROD_B,iseg,ROD_C,iseg])
	write_tetrahedra(tetrahedra)
	return	tetrahedra
#---------------------------------------------------------------------------------------------------------------------------------


#---------------------------------------------------------------------------------------------------------------------------------
#Write bond properties
#---------------------------------------------------------------------------------------------------------------------------------
def write_tetrahedra_properties(tetrahedra_properties):
	if not os.path.exists('data'):
		os.mkdir('data')
		
	with open('data'+'/tetrahedra_properties','w') as f:
		for i in range(0,len(tetrahedra_properties)):
			f.write(("%s" + "\n") %(tetrahedra_properties[i]))
	return
#---------------------------------------------------------------------------------------------------------------------------------
	


#---------------------------------------------------------------------------------------------------------------------------------
#Compute the equilibrium tetrahedral volume
#---------------------------------------------------------------------------------------------------------------------------------
def equilb_tetrahedra(tetrahedra,initpos,LENGTH,N_RODS,N_SEG,N_TETRAHEDRA):

	LS=LENGTH/N_SEG

	coords=np.zeros([N_RODS,N_SEG+1,3],dtype=float)
	
	#Initialise the vertex coordinates
	for irod in range(0,N_RODS):
		for iseg in range(0,N_SEG+1):
			coords[irod,iseg,0]=LS*iseg
			coords[irod,iseg,1]=initpos[irod][0]
			coords[irod,iseg,2]=initpos[irod][1]			
	
	tetrahedra_properties=np.zeros([N_TETRAHEDRA],dtype=float)
	for itet in range(0,N_TETRAHEDRA):
		#Extract the vertices of each corner of each tetrahedron
		r1=tetrahedra[itet][0]
		s1=tetrahedra[itet][1]
		r2=tetrahedra[itet][2]
		s2=tetrahedra[itet][3]		
		r3=tetrahedra[itet][4]
		s3=tetrahedra[itet][5]	
		r4=tetrahedra[itet][6]
		s4=tetrahedra[itet][7]
		
		v1=coords[r1,s1,:]
		v2=coords[r2,s2,:]
		v3=coords[r3,s3,:]		
		v4=coords[r4,s4,:]
		
		#Compute the edge vectors
		va=v2-v1
		vb=v3-v1
		vc=v4-v1
		
		#Compute the volume
		cross=np.cross(vb,vc)
		vol=abs(np.dot(va,cross)/6.0)

		tetrahedra_properties[itet]=vol		
	
	write_tetrahedra_properties(tetrahedra_properties)
	return
#---------------------------------------------------------------------------------------------------------------------------------
	
	
	
