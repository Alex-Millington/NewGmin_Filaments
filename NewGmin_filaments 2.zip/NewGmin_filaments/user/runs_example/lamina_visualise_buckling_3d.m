%% script to view the initial position of the 3d laminar bucklings system

PATHTORUNDIR='/local/scratch/zbj22yzu/NewGmin_filaments/user/runs_example/';
INITPOSNAME='data/init_pos';
ANGLESNAME='lowest';
NHEADER=4;

LENGTH=20;

savestat=1;

%% Read in data
initpos_in=importdata([PATHTORUNDIR '/' INITPOSNAME]);
N_RODS=length(initpos_in);

angles=importdata([PATHTORUNDIR '/' ANGLESNAME],'',NHEADER);
if NHEADER>0
    angles=angles.data;
end
N_SEG=length(angles)/(2*N_RODS);
LS=LENGTH/N_SEG;
NUM_ANGLES=N_RODS*N_SEG;

coords=zeros([N_RODS,N_SEG+1,3]);
for irod=1:N_RODS
    coords(irod,1,2)=initpos_in(irod,1);
    coords(irod,1,3)=initpos_in(irod,2);    
    coords(irod,1,1)=0;
        
    for iseg=2:N_SEG+1
        cur=(irod-1)*N_SEG+iseg-1;
        theta=angles(cur);
        phi=angles(NUM_ANGLES+cur);
        
        coords(irod,iseg,1)=coords(irod,iseg-1,1)+LS*cos(theta)*cos(phi);
        coords(irod,iseg,2)=coords(irod,iseg-1,2)+LS*sin(theta)*cos(phi);
        coords(irod,iseg,3)=coords(irod,iseg-1,3)+LS*sin(phi);
    end
end
    
verts=zeros(N_RODS*N_SEG+1,3);
s=1;
for irod=1:N_RODS
    for iseg=1:N_SEG+1
        verts(s,:)=coords(irod,iseg,:);
        s=s+1;
    end
end

%% plots







n_circ=12;
r_circ=0.1;
hold on
for irod=1:N_RODS
    
    verts=zeros(n_circ*(N_SEG+1),3);
    faces=zeros(n_circ*(N_SEG),4);
    for iseg=1:N_SEG+1
        if iseg==N_SEG+1
            l=squeeze(coords(irod,iseg,:)-coords(irod,iseg-1,:));
        else
            l=squeeze(coords(irod,iseg+1,:)-coords(irod,iseg,:));
        end
        lnorm=l/vecnorm(l);
        n=[1;-1*l(1)/l(2);0];       
        n=n/vecnorm(n)*r_circ;
        
        if n(2)<0
            n=-n;
        end
        
        for icirc=1:n_circ
            theta=2*pi*icirc/n_circ;
            
            n_rot=zeros(3);
            n_rot=n*cos(theta)+cross(lnorm,n).*sin(theta)+lnorm.*dot(lnorm,n).*(1-cos(theta));
            
            
            %n_rot(3)=1.0;
            %n_rot(2)=(cos(theta)+n_rot(3)*(n(1)/l(1)*l(3)-n(3)))/(n(2)+(n(1)/l(1)*l(2)));
            %n_rot(1)=-1/l(1)*(n_rot(2)*l(2)+n_rot(3)*l(3));
            
            %n_rot=n_rot/vecnorm(n_rot)*r_circ;
            n_rot(1)=n_rot(1)+coords(irod,iseg,1);
            n_rot(2)=n_rot(2)+coords(irod,iseg,2);
            n_rot(3)=n_rot(3)+coords(irod,iseg,3);
            
            verts((iseg-1)*(n_circ)+icirc,:)=n_rot;
        end    
    end
    
    for iseg=1:N_SEG
        for icirc=1:n_circ-1
            faces((iseg-1)*n_circ+icirc,1)=(iseg-1)*(n_circ)+icirc;
            faces((iseg-1)*n_circ+icirc,2)=(iseg)*(n_circ)+icirc;
            faces((iseg-1)*n_circ+icirc,3)=(iseg)*(n_circ)+icirc+1;
            faces((iseg-1)*n_circ+icirc,4)=(iseg-1)*(n_circ)+icirc+1;
        end
        faces((iseg-1)*n_circ+n_circ,1)=(iseg-1)*(n_circ)+n_circ;
        faces((iseg-1)*n_circ+n_circ,2)=(iseg)*(n_circ)+n_circ;
        faces((iseg-1)*n_circ+n_circ,3)=(iseg)*(n_circ)+1;
        faces((iseg-1)*n_circ+n_circ,4)=(iseg-1)*(n_circ)+1;
        
    end
    plot3(coords(irod,:,1),coords(irod,:,2),coords(irod,:,3));
    %scatter3(verts(:,1),verts(:,2),verts(:,3),'filled','k')
    p=patch('Faces',faces,'Vertices',verts,'FaceColor','r','EdgeColor','none');
end
axis equal
axis tight
%set(gca,'Box','on','BoxStyle','full','LineWidth',1.5)
% Lighting
light('Position',[1 0.7 0.7])
material shiny
lighting phong
view([0.5 -0.6 0.3])

if savestat==1
    print(gcf, '-dpng', '-r600', [PATHTORUNDIR '/' ANGLESNAME '_img'])
end
%end
